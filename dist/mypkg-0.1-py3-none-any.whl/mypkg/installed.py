def run():
    print("installed pkg")
